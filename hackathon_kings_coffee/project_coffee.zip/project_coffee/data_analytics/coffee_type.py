import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def compare_coffee_types(sales_data):
    coffee_count = sales_data['coffee_type'].value_counts()

    print('coffee type comparison: ')
    print(coffee_count)

    labels = coffee_count.index
    values = coffee_count.values
    plt.bar(labels, values, color = ['lightcyan', 'paleturquoise'])
    plt.xlabel('coffee type')
    plt.ylabel('coffee sales')
    plt.show()