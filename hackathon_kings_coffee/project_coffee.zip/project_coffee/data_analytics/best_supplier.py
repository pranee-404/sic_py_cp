import pandas as pd
import matplotlib.pyplot as plt

def supplier_data_analysis(sales_data):
    coffee_suppliers = {
        'Filter': 'Bean Bakery',
        'Latte': 'Kiwi Koffee',
        'Dalgona': 'Espresso co.',
        'Black': 'Bean Bakery',
        'Espresso': 'Fresh Coffee',
        'Cappucino': 'Kiwi Koffee'
    }
    sales_data['supplier'] = sales_data['coffee_type'].map(coffee_suppliers)
    supplier_performance = sales_data.groupby('supplier')['total_sale'].sum()
    sorted_supplier_performance = supplier_performance.sort_values(ascending = False)
    sorted_supplier_performance.plot(kind = 'bar', color = 'tan')
    plt.xlabel('Supplier')
    plt.ylabel('Total Sales')
    plt.title('Supplier Performance by Total Sales')
    plt.show()