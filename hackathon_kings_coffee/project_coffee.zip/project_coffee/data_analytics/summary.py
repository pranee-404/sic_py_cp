import matplotlib.pyplot as plt

def show_summary(app_instance):
    sales_data = app_instance
    
    plt.figure(figsize=(10, 8))

    plt.subplot(2, 2, 1)
    coffee_count = sales_data['coffee_type'].value_counts()
    coffee_count.plot(kind='bar', color='brown')
    plt.title('Coffee Types Sold')
    plt.xticks(rotation=45)

    plt.subplot(2, 2, 2)
    date_sales = sales_data.groupby('date')['total_sale'].sum()
    date_sales.plot(color='green')
    plt.title('Daily Sales')

    plt.subplot(2, 2, 3)
    coffee_suppliers = {
        'Filter': 'Bean Bakery',
        'Latte': 'Kiwi Koffee',
        'Dalgona': 'Espresso co.',
        'Black': 'Bean Bakery',
        'Espresso': 'Fresh Coffee',
        'Cappucino': 'Kiwi Koffee'
    }
    sales_data['supplier'] = sales_data['coffee_type'].map(coffee_suppliers)
    supplier_perf = sales_data.groupby('supplier')['total_sale'].sum()
    supplier_perf.plot(kind='bar', color='skyblue')
    plt.title('Supplier Sales')
    plt.xticks(rotation=30)

    plt.subplot(2, 2, 4)
    forecast = sales_data.groupby('date')['total_sale'].sum().rolling(window=3).mean()
    forecast.plot(color='orange')
    plt.title('Revenue Forecast')

    plt.tight_layout()
    plt.show()
