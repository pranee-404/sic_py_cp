import pandas as pd
import matplotlib.pyplot as plt

def feedback_summary(feedback_data):
    avg_rating = feedback_data['rating'].mean()
    positive = feedback_data[feedback_data['rating'] >= 4].shape[0]
    neutral = feedback_data[feedback_data['rating'] == 3].shape[0]
    negative = feedback_data[feedback_data['rating'] <= 2].shape[0]
    total = len(feedback_data)

    labels = ['Positive', 'Neutral', 'Negative']
    values = [positive,neutral,negative]
    colors = ['thistle', 'plum', 'violet']

    plt.pie(values, labels = labels, colors = colors, autopct= '%1.1f%%')
    plt.title('Customer Feedback Summary')
    plt.show()