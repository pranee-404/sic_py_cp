import pandas as pd

def estimate_supply_usage(sales_data):
    total_orders = len(sales_data)
    sweetener_usage = sales_data['sweetener'].value_counts()
    supply_usage = {
        'Coffee Beans' : total_orders,
        'Milk' : total_orders
    }
    for sweetener, count in sweetener_usage.items():
        supply_usage[sweetener] = count

    return supply_usage

def restock_signal(supply_usage, limit = 50):
    for item, usage in supply_usage.items():
        if usage > limit:
            print(f'Restock Needed for {item}.')
        else:
            print(f'{item} stock is available.')