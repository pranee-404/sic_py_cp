import pandas as pd 
import matplotlib.pyplot as plt

def forecast_revenue(sales_data):
    daily_sales = sales_data.groupby('date')['total_sale'].sum().sort_index()
    forecast = daily_sales.rolling(window = 3).mean()
    plt.figure(figsize=(15,6))
    x = daily_sales.index
    y = daily_sales.values
    x1 = forecast.index
    y1 = forecast.values
    plt.plot(x, y, label='Actual Sales', color='deepskyblue')
    plt.plot(x1, y1, label='Forecast (3-day Avg)', color='salmon', linestyle='--')
    plt.xlabel('Date')
    plt.ylabel('Revenue')
    plt.xticks(rotation=90)
    plt.title('Daily Revenue Forecast')
    plt.show()