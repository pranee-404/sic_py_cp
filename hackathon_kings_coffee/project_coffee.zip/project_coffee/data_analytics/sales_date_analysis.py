import pandas as pd
import matplotlib.pyplot as plt

def sales_date_analysis(sales_data):
    total_sales = sales_data.groupby('date')['total_sale'].sum()
    sorted_sales = total_sales.sort_values(ascending = False)
    x = sorted_sales.index
    y = sorted_sales.values
    plt.figure(figsize=(15, 6))
    plt.bar(x, y, color = 'orchid')
    plt.title('Analysis of Total Sales based on dates')
    plt.xlabel('Dates')
    plt.ylabel('Total sales')
    plt.xticks(rotation=90)
    plt.tight_layout()
    plt.show()