import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def top_coffee_types(sales_data, top_n = 3):
    #group the total quantity of sales
    coffee_sales = sales_data.groupby('coffee_type')['quantity'].sum()
    #sort the values into descending order so that the top values will come
    sorted_sales = coffee_sales.sort_values(ascending = False)
    top_coffee_sales = sorted_sales[:3]
    x = top_coffee_sales.index
    y = top_coffee_sales.values
    plt.bar(x, y, color = 'peru')
    plt.title('Top Coffee types by Sales')
    plt.xlabel('Coffee types')
    plt.ylabel('Total Sales')
    plt.show()