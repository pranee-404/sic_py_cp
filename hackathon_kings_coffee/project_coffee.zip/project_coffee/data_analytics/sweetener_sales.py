import pandas as pd
import matplotlib.pyplot as plt

def analyze_sweeteners(sales_data):
    sweetener_count = sales_data['sweetener'].value_counts()

    x = sweetener_count.index
    y = sweetener_count.values
    plt.bar(x, y, color = 'lightpink')
    plt.title('Usage of Sweetener')
    plt.xlabel('Sweetener types')
    plt.ylabel('Number of orders')
    plt.show()