import pandas as pd
import random
from datetime import datetime

def generate_sale(order_id):
    coffee_types = ['Filter', 'Latte', 'Dalgona', 'Black', 'Espresso', 'Cappucino']
    sweeteners = ['Sugar', 'Brown sugar', 'Jaggery', 'No sugar']

    coffee = random.choice(coffee_types)
    sweetener = random.choice(sweeteners)
    quantity = random.randint(1,5)

    coffee_prices = {
        'Filter' : 50,
        'Latte' : 80,
        'Dalgona' : 100,
        'Black' : 60,
        'Espresso': 90,
        'Cappucino' : 110
    }

    random_datetime = datetime(
        year=random.randint(2023, 2025),
        month=random.randint(1, 12),
        day=random.randint(1, 28),
        hour=random.randint(0, 23),
        minute=random.randint(0, 59),
        second=random.randint(0, 59)
    )

    price_per_cup = coffee_prices[coffee]
    total_sale = quantity * price_per_cup
    
    return {
        'order_id' : order_id, 
        'coffee_type' : coffee,
        'sweetener' : sweetener,
        'quantity' : quantity,
        'price_per_cup' : price_per_cup,
        'total_sale' : total_sale,
        'date' : random_datetime.strftime('%Y-%m-%d'),
        'time' : random_datetime.time().strftime('%H:%M')
    }

def generate_sales_dataset(records):
    return [generate_sale(i+1) for i in range(records)]
    
sales_data = generate_sales_dataset(100)
df = pd.DataFrame(sales_data)
df.to_csv('project_coffee/data/sales_data.csv', index = False)

#print(generate_sale(101))