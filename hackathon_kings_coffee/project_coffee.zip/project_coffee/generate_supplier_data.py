import pandas as pd
import random

def generate_suppliers(supplier_id, name, item):
    quantity = random.randint(100,300)
    price_list = {
        'Coffee Beans' : 200,
        'Sugar' : 50,
        'Paper cups' : 15,
        'Milk' : 35,
        'Syrup' : 75,
        'Straws' : 5
    }
    cost_per_item = price_list[item]
    total_cost = cost_per_item * quantity

    return {
        'supplier_id' : supplier_id,
        'name' : name,
        'item_supplied' : item,
        'quantity' : quantity,
        'cost_per_item' : cost_per_item,
        'total_price' : total_cost
    }

def generate_supplier_data(n = 100):
    suppliers = ['Fresh Coffee', 'Kiwi Koffee', 'Sugary Sweet co', 'CupMart', 'Bean Bakery', 'Creamy Delights']
    item_types = ['Sugar', 'Syrup', 'Straws', 'Milk', 'Paper cups', 'Coffee Beans']

    data = []
    for supplier_id in range(1,n+1):
        name = random.choice(suppliers)
        item = random.choice(item_types)
        entry = generate_suppliers(supplier_id, name, item)
        data.append(entry)

    df = pd.DataFrame(data)
    df.to_csv('project_coffee/data/supplier_data.csv', index = False)

generate_supplier_data(100)