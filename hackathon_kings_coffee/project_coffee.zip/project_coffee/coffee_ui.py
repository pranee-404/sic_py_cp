import tkinter as tk
from tkinter import messagebox
from helper_code import load_all_data
from coffee_shop import KingsCoffee

sales_data, supplier_data, feedback_data = load_all_data()
app = KingsCoffee(sales_data, supplier_data, feedback_data)

def show_welcome():
    welcome_window = tk.Tk()
    welcome_window.title("Welcome")
    welcome_window.configure(bg = "#e9d3b9")

    tk.Label(welcome_window, text="☕ Welcome to Kings Coffee ☕", font=("Arial", 16), image = '').pack(padx=20, pady=20)
    tk.Button(welcome_window, 
              text="Enter", 
              font=("Arial", 12), 
              bg ='#c19a6b',
              command=welcome_window.destroy
              ).pack(pady=10)

    welcome_window.mainloop()

def run_analysis(option):
    try:
        if option == "Compare Coffee Types":
            app.run_coffee_types()
        elif option == "Sweetener Sales":
            app.run_sweetener_sales()
        elif option == "Top Coffee Types":
            app.run_top_coffee()
        elif option == "Forecast Revenue":
            app.run_forecast_analysis()
        elif option == "Sales by Date":
            app.run_sales_analysis()
        elif option == "Supplier Performance":
            app.run_supplier_analysis()
        elif option == "Restock Alert":
            app.run_restock_alert()
        elif option == "Feedback Summary":
            app.run_feedback_summary()
        elif option == "Summary":
            app.run_show_summary()
        else:
            messagebox.showinfo("Error", "Unknown Option Selected!")
    except Exception as e:
        messagebox.showerror("Error", f"Something went wrong: {e}")

show_welcome()
root = tk.Tk()
root.title("Kings Coffee - Data Analytics")
root.geometry("500x600")
root.configure(bg = "#e9d3b9")


tk.Label(root, text="☕Kings Coffee☕", font=("Arial", 18)).pack(pady=20)


menu_options = [
    "Compare Coffee Types",
    "Sweetener Sales",
    "Top Coffee Types",
    "Forecast Revenue",
    "Sales by Date",
    "Supplier Performance",
    "Restock Alert",
    "Feedback Summary",
    "Summary"
]


for option in menu_options:
    tk.Button(
        root,
        text=option,
        font=("Arial", 12),
        bg ='#c19a6b',
        width=30,
        command=lambda opt=option: run_analysis(opt)
    ).pack(pady=8)


root.mainloop()