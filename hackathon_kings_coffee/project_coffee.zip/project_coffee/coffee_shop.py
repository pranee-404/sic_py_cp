import pandas as pd
from helper_code import load_all_data

from data_analytics import sweetener_sales
from data_analytics.coffee_type import compare_coffee_types
from generate_sales_data import generate_sale
from data_analytics.top_coffee import top_coffee_types
from data_analytics.sales_date_analysis import sales_date_analysis
from data_analytics.forecast_analysis import forecast_revenue
from data_analytics.restock_alert_system import estimate_supply_usage, restock_signal
from data_analytics.best_supplier import supplier_data_analysis
from data_analytics.feedback_analysis import feedback_summary
from data_analytics.summary import show_summary

sales_data, supplier_data, feedback_data = load_all_data()

class KingsCoffee:
    def __init__(self, sales_data, supplier_data, feedback_data):   
        self.sales_data = sales_data
        self.supplier_data = supplier_data
        self.feedback_data = feedback_data
    
    def run_coffee_types(self):
        result = compare_coffee_types(self.sales_data)
        print(result)

    def run_sweetener_sales(self):
        return sweetener_sales.analyze_sweeteners(self.sales_data)
    
    def run_top_coffee(self):
        result = top_coffee_types(self.sales_data)
        print(result)

    def run_restock_alert(self):
        supply_usage = estimate_supply_usage(self.sales_data)
        result = restock_signal(supply_usage,limit = 50)
        print(result)

    def run_forecast_analysis(self):
        result  = forecast_revenue(self.sales_data)
        print(result)
    
    def run_sales_analysis(self):
        result = sales_date_analysis(self.sales_data)
        print(result)

    def run_supplier_analysis(self):
        result = supplier_data_analysis(self.sales_data)
        print(result)
    
    def run_feedback_summary(self):
        result = feedback_summary(self.feedback_data)
        print(result)
    
    def run_show_summary(self):
        result = show_summary(self.sales_data)
        print(result)

    def run_all(self):
        self.run_coffee_types()
        self.run_sweetener_sales()
        self.run_top_coffee()
        self.run_restock_alert()
        self.run_forecast_analysis()
        self.run_sales_analysis()
        self.run_supplier_analysis()
        self.run_feedback_summary()
        self.run_show_summary()