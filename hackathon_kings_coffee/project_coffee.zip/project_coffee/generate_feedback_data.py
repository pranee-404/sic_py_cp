import pandas as pd
import random
from datetime import datetime

def generate_feedback(feedback_id):
    coffee_types = ['Filter', 'Latte', 'Dalgona', 'Black', 'Espresso', 'Cappucino']
    comments = ['Loved it', 'Too bitter', 'Perfect', 'Not hot enough', 'Too sweet', 'Very nice']
    
    coffee = random.choice(coffee_types)
    comment = random.choice(comments)
    rating = random.randint(1,5)
    random_date = datetime(
        year=random.randint(2023, 2025),
        month=random.randint(1, 12),
        day=random.randint(1, 28)
    )

    return {
        'feedback_id' : feedback_id,
        'coffee_type' : coffee,
        'rating' : rating,
        'comment' : comment,
        'date' : random_date.strftime('%Y-%m-%d')
    }

def generate_feedback_data(n = 100):
    data = []
    for feedback_id in range(1,n+1):
        entry = generate_feedback(feedback_id)
        data.append(entry)
    df = pd.DataFrame(data)
    df.to_csv('project_coffee/data/customer_feedback.csv', index = False)

generate_feedback_data(100)