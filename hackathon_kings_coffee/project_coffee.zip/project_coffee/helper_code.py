import pandas as pd

def load_all_data():
    sales_data = pd.read_csv('project_coffee/data/sales_data.csv')
    supplier_data = pd.read_csv('project_coffee/data/supplier_data.csv')
    feedback_data = pd.read_csv('project_coffee/data/customer_feedback.csv')
    return sales_data, supplier_data, feedback_data